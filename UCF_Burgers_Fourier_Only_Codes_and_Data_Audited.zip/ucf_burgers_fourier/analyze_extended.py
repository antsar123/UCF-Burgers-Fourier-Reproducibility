#!/usr/bin/env python3
"""Recompute sharp-front aggregates and paired tests from archived CSV files.

Run:
    python analyze_extended.py
Outputs:
    results/recomputed_sharp_front_aggregate.csv
    results/recomputed_paired_tests.csv
    results/recomputed_analysis.json

This script does not fabricate missing benchmark outputs. It only analyzes
the per-case CSV files shipped with this package.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from statsmodels.stats.multitest import multipletests

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)
BASE = RESULTS / "sharp_front_multiseed_per_case.csv"
EV = RESULTS / "entropy_sharp_front_per_case.csv"

def read_csv(path):
    if not path.exists():
        raise FileNotFoundError(f"Required input is missing: {path.name}")
    return pd.read_csv(path)

def main():
    base, ev = read_csv(BASE), read_csv(EV)
    all_data = pd.concat([base, ev], ignore_index=True)
    required = {"seed","case","label","l2_rel","overshoot_pct","collapsed"}
    missing = required - set(all_data.columns)
    if missing:
        raise ValueError(f"Missing columns: {sorted(missing)}")
    all_data["l2_rel"] = pd.to_numeric(all_data["l2_rel"], errors="coerce")
    all_data["overshoot_pct"] = pd.to_numeric(all_data["overshoot_pct"], errors="coerce")
    all_data["collapsed"] = all_data["collapsed"].astype(str).str.lower().isin(["true","1","yes"])
    valid = all_data.loc[~all_data["collapsed"]].copy()

    agg = (valid.groupby("label", dropna=False)
           .agg(n=("case","size"),
                mean_l2=("l2_rel","mean"),
                median_l2=("l2_rel","median"),
                p95_l2=("l2_rel",lambda x: x.quantile(.95)),
                mean_overshoot_pct=("overshoot_pct","mean"),
                median_overshoot_pct=("overshoot_pct","median"),
                p95_overshoot_pct=("overshoot_pct",lambda x: x.quantile(.95)))
           .reset_index())
    agg.to_csv(RESULTS/"recomputed_sharp_front_aggregate.csv", index=False)

    wide = valid.pivot_table(index=["seed","case"], columns="label",
                             values="l2_rel", aggfunc="first")
    if "UCF_DNI" not in wide.columns:
        raise ValueError("UCF_DNI column is absent from the supplied CSVs.")
    comparators = [c for c in wide.columns if c != "UCF_DNI"]
    tests, pvals = [], []
    for name in comparators:
        pair = wide[["UCF_DNI",name]].dropna()
        if len(pair) < 2:
            continue
        delta = pair["UCF_DNI"] - pair[name]
        result = wilcoxon(pair["UCF_DNI"], pair[name],
                          zero_method="wilcox", alternative="two-sided",
                          method="auto")
        tests.append({
            "contrast": f"UCF_DNI vs {name}",
            "n_paired": int(len(pair)),
            "median_delta_UCF_minus_comparator": float(delta.median()),
            "mean_delta_UCF_minus_comparator": float(delta.mean()),
            "p_raw": float(result.pvalue)
        })
        pvals.append(float(result.pvalue))
    if pvals:
        adjusted = multipletests(pvals, method="holm")[1]
        for row, p in zip(tests, adjusted):
            row["p_holm"] = float(p)
    pd.DataFrame(tests).to_csv(RESULTS/"recomputed_paired_tests.csv", index=False)
    payload = {
        "source_files": [BASE.name, EV.name],
        "rows_total": int(len(all_data)),
        "rows_noncollapsed": int(len(valid)),
        "aggregate": agg.to_dict(orient="records"),
        "paired_tests": tests,
        "interpretation": (
            "Descriptive results for the supplied finite benchmark only; "
            "they do not establish universal superiority."
        )
    }
    (RESULTS/"recomputed_analysis.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8")
    print(agg.to_string(index=False))
    print("\\nPaired tests (Holm-adjusted):")
    print(pd.DataFrame(tests).to_string(index=False))

if __name__ == "__main__":
    main()

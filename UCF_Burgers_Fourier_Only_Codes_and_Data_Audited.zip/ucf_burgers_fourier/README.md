# UCF Burgers — Fourier code, results and figure scripts

Companion material for the UCF–Burgers manuscript (periodic Fourier-collocation study).

## Quick start
```bash
pip install -r requirements.txt
python ucf_burgers.py verify
python ucf_burgers.py calib
python ucf_burgers.py test
python make_figures.py --outdir figures
python run_full_reproducibility.py
```
Run from this directory. Back up `results/` before a full run because result files may be overwritten.

## Verification status
`verify`, `calib`, and `test` (500 cases) were re-run from scratch in a clean copy and reproduced the archived outputs bit-identically (see `RERUN_LOG_2026-11-23.txt`). The remaining listed stages and their scope are documented in `EXECUTED_COMMANDS_2026-11-23.txt` and `AUDIT_STATUS_2026-11-23.md`.

## Figures
`make_figures.py` regenerates Figures 1–5 from the Fourier implementation and archived results. Figure 1(a) and Figure 2 are re-simulated; other panels are drawn from stored arrays. Layout and fonts may differ slightly from manuscript graphics.

## Scope and limitations
This archive contains the available periodic Fourier-collocation implementation and its results. It does not claim to provide a complete build pipeline for the manuscript or direct matched implementations of Chan-type entropy-correction DG and NOES-DG. The EV comparator is a residual-based adaptation for viscous Burgers/Fourier, not a bitwise reproduction of every detail of the canonical method.

## Deposit status
No public repository deposit or DOI is claimed. Add a DOI to `CITATION.cff` and the manuscript only after an actual public deposit.

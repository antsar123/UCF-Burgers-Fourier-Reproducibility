#!/usr/bin/env python3
"""Run the reproducibility workflow in dependency order.

Usage:
  python run_reproducibility.py --through verify
  python run_reproducibility.py --through calibration
  python run_reproducibility.py --through expanded
  python run_reproducibility.py --through sharp
  python run_reproducibility.py --through all

The full `all` workflow can take substantial time. Existing archived results
are not overwritten unless the corresponding stage is explicitly rerun.
"""
import argparse, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STAGES={
  "verify": [("ucf_burgers.py","verify")],
  "calibration": [("ucf_burgers.py","verify"),("ucf_burgers.py","calib")],
  "expanded": [("ucf_burgers.py","verify"),("ucf_burgers.py","calib"),("extended_benchmark.py",)],
  "sharp": [("ucf_burgers.py","verify"),("ucf_burgers.py","calib"),("extended_benchmark.py",),("run_entropy_sharp.py",),("analyze_extended.py",)],
  "all": [("ucf_burgers.py","verify"),("ucf_burgers.py","calib"),("ucf_burgers.py","test"),("ucf_burgers.py","sweep"),("extended_benchmark.py",),("run_entropy_sharp.py",),("analyze_extended.py",)]
}
p=argparse.ArgumentParser(); p.add_argument('--through',choices=STAGES,default='verify'); a=p.parse_args()
for cmd in STAGES[a.through]:
    print('\n>>>', ' '.join(cmd), flush=True)
    subprocess.run([sys.executable,*cmd],cwd=ROOT,check=True)
print('\nWorkflow completed:',a.through)

# UCF Burgers manuscript: final reproducibility audit (23 November 2026)

## Checks completed in this audit
- ZIP integrity: passed; all archive entries extracted without errors.
- Python syntax compilation: passed for all seven supplied Python scripts.
- Figure regeneration: `python make_figures.py --outdir /tmp/ucf_figcheck` completed and regenerated Figures 1–5.
- Sharp-front aggregate analysis: a path defect was found in `analyze_extended.py` (it looked for two CSV inputs in the project root although the archive stores them under `results/`). The paths were corrected to `results/`; the script then completed successfully.
- Recomputed 168 case rows (24 matched cases for each of seven methods); no missing case matches or collapsed cases in this benchmark.
- Recomputed means and paired Wilcoxon tests with Holm adjustment. Results agree with the manuscript to displayed precision.

## Recomputed sharp-front results
| Method | Mean relative L2 | Mean overshoot (%) |
|---|---:|---:|
| UCF-DNI | 0.092401 | 2.210968 |
| Spectral viscosity | 0.031972 | 11.970684 |
| Modal decay | 0.064767 | 0.110548 |
| Uniform viscosity | 0.043407 | 1.928590 |
| Skew without artificial viscosity | 0.095169 | 12.711772 |
| EV accuracy | 0.049310 | 1.651228 |
| EV low-overshoot | 0.106555 | 0.630329 |

## Interpretation
SVV has the lowest mean L2 error; modal decay has the lowest mean overshoot. EV-accuracy outperforms UCF on both reported means in this finite 24-case benchmark; EV-low-overshoot reduces overshoot further at the cost of larger L2 error. These results do not establish universal superiority.

## Scope limitations
The EV comparator is a residual-based viscous-Burgers/Fourier adaptation, not a canonical bitwise reproduction of every detail of Guermond–Pasquetti–Popov. Chan-type entropy-correction DG and NOES-DG are not direct matched head-to-head tests. The full end-to-end workflow is computationally intensive and was not rerun in its entirety during this final audit. The existing run log documents prior clean reruns of `verify`, `calib`, and `test`.

## Deposit status
No public repository deposit or DOI is claimed.

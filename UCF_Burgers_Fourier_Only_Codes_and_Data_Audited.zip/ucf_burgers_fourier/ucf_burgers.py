#!/usr/bin/env python3
"""
UCF study: energy-stable skew-symmetric splitting with a Leibniz-defect (DNI)
sensor for the viscous Burgers equation  u_t + u u_x = nu u_xx  on [0, 2*pi).

Everything reported in the paper is produced by this file:
    python3 ucf_burgers.py verify    # identities, Proposition 2, reference check
    python3 ucf_burgers.py calib     # calibration (seed 2024, 60 cases)
    python3 ucf_burgers.py test      # test (seed 777, 500 cases)
    python3 ucf_burgers.py sweep     # resolution sweep N = 64, 128, 256
Outputs go to ./results/*.json and ./results/*.npz
"""
import sys, json, time, itertools, os
import numpy as np
from numpy.fft import rfft, irfft

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "results")
os.makedirs(OUT, exist_ok=True)

T_FINAL = 2.0
DT = 2e-3
N0 = 128
COLLAPSE_LEVEL = 10.0        # |u|_inf > 10 * max|u0| (max|u0| = 1) or non-finite


# ----------------------------------------------------------------------------
# test cases and exact (Hopf-Cole) solution
# ----------------------------------------------------------------------------
def make_cases(seed, n, K=4, family="trig4"):
    """Random zero-mean trigonometric initial data with max|u0| = 1 and
    viscosity log-uniform in [1e-3, 1e-2].
    family 'trig4' : 4 modes, coefficients ~ N(0,1/k^2)         (main study)
    family 'flat8' : 8 modes, coefficients ~ N(0,1/k)           (richer spectrum)
    family 'saw12' : randomly shifted 12-term sawtooth series   (sharp fronts from t = 0)"""
    rng = np.random.default_rng(seed)
    nu = 10 ** rng.uniform(-3.0, -2.0, n)
    if family == "trig4":
        kk = np.arange(1, K + 1)
        a = rng.normal(size=(n, K)) / kk
        b = rng.normal(size=(n, K)) / kk
    elif family == "flat8":
        K = 8
        kk = np.arange(1, K + 1)
        a = rng.normal(size=(n, K)) / np.sqrt(kk)
        b = rng.normal(size=(n, K)) / np.sqrt(kk)
    elif family == "saw12":
        K = 12
        kk = np.arange(1, K + 1)
        phi = rng.uniform(0, 2 * np.pi, n)
        c = (-1.0) ** (kk + 1) / kk
        a = c[None, :] * np.cos(np.outer(phi, kk))
        b = -c[None, :] * np.sin(np.outer(phi, kk))
    else:
        raise ValueError(family)
    xf = 2 * np.pi * np.arange(8192) / 8192
    for i in range(n):
        u = (a[i][:, None] * np.sin(np.outer(kk, xf)) +
             b[i][:, None] * np.cos(np.outer(kk, xf))).sum(0)
        sc = np.abs(u).max()
        a[i] /= sc
        b[i] /= sc
    return nu, a, b


def u0_on_grid(a, b, N):
    x = 2 * np.pi * np.arange(N) / N
    K = a.shape[1]
    kk = np.arange(1, K + 1)
    S = np.sin(np.outer(kk, x))
    C = np.cos(np.outer(kk, x))
    return a @ S + b @ C


def hopf_cole(a, b, nu, t, x, hfac=16, lfac=8.0):
    """Exact solution for u0 = sum a_k sin(kx) + b_k cos(kx), periodic.
    u(x,t) = int (x-y)/t exp(-F/2nu) dy / int exp(-F/2nu) dy,
    F = (x-y)^2/(2t) + G(y),  G(y) = int_0^y u0.   (max|u0| = 1)"""
    K = a.size
    kk = np.arange(1, K + 1)
    sig = np.sqrt(2 * nu * t)
    L = t * 1.0 + lfac * sig
    h = sig / hfac
    m = int(np.ceil(2 * L / h))
    s = np.linspace(-L, L, m + 1)
    Y = x[:, None] + s[None, :]
    G = np.zeros_like(Y)
    for k in range(K):
        G += a[k] * (1 - np.cos((k + 1) * Y)) / (k + 1) + b[k] * np.sin((k + 1) * Y) / (k + 1)
    F = (s ** 2 / (2 * t))[None, :] + G
    ex = -F / (2 * nu)
    ex -= ex.max(axis=1, keepdims=True)
    w = np.exp(ex)
    return ((-s / t)[None, :] * w).sum(1) / w.sum(1)


def exact_batch(a, b, nu, t, N):
    x = 2 * np.pi * np.arange(N) / N
    return np.array([hopf_cole(a[i], b[i], nu[i], t, x) for i in range(len(nu))])


# ----------------------------------------------------------------------------
# spatial operators and time stepping (batched over cases)
# ----------------------------------------------------------------------------
def simulate(method, params, nu, u0, T, dt, rec_every=0):
    B, N = u0.shape
    dx = 2 * np.pi / N
    k = np.arange(N // 2 + 1).astype(float)
    ik = 1j * k
    ik[-1] = 0.0                                  # Nyquist mode removed: D^T = -D
    mask23 = (k <= N // 3).astype(float)
    L = -nu[:, None] * k[None, :] ** 2

    if method == "skew_svv":
        e0, m = params["e0"], params["m"]
        Q = np.zeros_like(k)
        hi = k > m
        Q[hi] = np.exp(-((k[hi] - N / 2) / (k[hi] - m)) ** 2)
        L = L - (e0 * dx) * Q[None, :] * k[None, :] ** 2
    if method == "skew_pp":
        kc = N // 4
        hp = (k > kc).astype(float)
        sm = np.exp(-(k * 3.0 * dx) ** 2 / 2)     # Gaussian window, 3 grid points

    def Dx(v):
        return irfft(ik * v, n=N, axis=1)

    def f(v):
        if method == "adv_dealias":
            v = v * mask23
        u = irfft(v, n=N, axis=1)
        ux = Dx(v)
        extra = None
        if method in ("adv", "adv_dealias"):
            nl = u * ux
        elif method == "cons":
            nl = 0.5 * irfft(ik * rfft(u * u, axis=1), n=N, axis=1)
        else:                                      # skew-symmetric family
            du2 = irfft(ik * rfft(u * u, axis=1), n=N, axis=1)
            nl = (u * ux + du2) / 3.0
            if method == "ucf":
                U = np.abs(u).max(axis=1, keepdims=True)
                delta = du2 - 2.0 * u * ux          # discrete Leibniz defect
                ad = np.abs(delta)
                S = ad / (ad.max(axis=1, keepdims=True) + params["eta"] * U ** 2)
                extra = params["c1"] * dx * U * S
            elif method == "skew_const":                 # control: uniform viscosity c1*h*U, no sensor
                U = np.abs(u).max(axis=1, keepdims=True)
                extra = params["c1"] * dx * U * np.ones_like(u)
            elif method in ("ucfL", "ucfQ"):             # locally normalised defect sensors
                U = np.abs(u).max(axis=1, keepdims=True)
                ad = np.abs(du2 - 2.0 * u * ux)
                ref = params["eta"] * U ** 2 / dx       # grid-scaled reference level, units of delta
                S = ad / (ad + ref) if method == "ucfL" else ad ** 2 / (ad ** 2 + ref ** 2)
                extra = params["c1"] * dx * U * S
            elif method == "skew_pp":
                U = np.abs(u).max(axis=1, keepdims=True)
                uhp = irfft(v * hp, n=N, axis=1)
                Ehp = np.maximum(irfft(rfft(uhp * uhp, axis=1) * sm, n=N, axis=1), 0.0)
                Etot = np.maximum(irfft(rfft(u * u, axis=1) * sm, n=N, axis=1), 0.0)
                s = np.log10(Ehp / (Etot + 1e-8 * U ** 2) + 1e-30)
                s0, kap = params["s0"], 1.0
                ramp = np.where(s < s0 - kap, 0.0,
                                np.where(s > s0 + kap, 1.0,
                                         0.5 * (1 + np.sin(np.pi * (s - s0) / (2 * kap)))))
                extra = params["c1"] * dx * U * ramp
        out = -rfft(nl, axis=1)
        if method == "adv_dealias":
            out = out * mask23
        if extra is not None:
            out = out + ik * rfft(extra * ux, axis=1)
        return out

    E = np.exp(L * dt / 2)
    E2 = E * E
    v = rfft(u0, axis=1)
    nsteps = int(round(T / dt))
    collapsed = np.zeros(B, dtype=bool)
    maxu = np.abs(u0).max(axis=1)
    hist = []
    with np.errstate(all="ignore"):
        if rec_every:
            hist.append(np.mean(u0 ** 2, axis=1))
        for n in range(nsteps):
            a1 = f(v)
            b1 = f(E * (v + 0.5 * dt * a1))
            c1 = f(E * v + 0.5 * dt * b1)
            d1 = f(E2 * v + dt * E * c1)
            v = E2 * v + dt / 6.0 * (E2 * a1 + 2 * E * (b1 + c1) + d1)
            u = irfft(v, n=N, axis=1)
            m = np.abs(u).max(axis=1)
            bad = (~np.isfinite(m)) | (m > COLLAPSE_LEVEL)
            if bad.any():
                collapsed |= bad
                v[bad] = 0.0
                m = np.where(bad, 0.0, m)
            maxu = np.maximum(maxu, np.where(collapsed, 0.0, m))
            if rec_every and (n + 1) % rec_every == 0:
                hist.append(np.where(collapsed, np.nan, np.mean(u ** 2, axis=1)))
    u = irfft(v, n=N, axis=1)
    u[collapsed] = np.nan
    return dict(u=u, collapsed=collapsed, maxu=np.where(collapsed, np.nan, maxu),
                hist=np.array(hist) if rec_every else None)


def metrics(res, uex):
    u = res["u"]
    col = res["collapsed"]
    with np.errstate(all="ignore"):
        l2 = np.linalg.norm(u - uex, axis=1) / np.linalg.norm(uex, axis=1)
        en = np.mean(u ** 2, axis=1) / np.mean(uex ** 2, axis=1)
        over = np.maximum(res["maxu"] - 1.0, 0.0) * 100.0      # percent of max|u0|
    return dict(l2=l2, en=en, over=over, collapsed=col)


def summarise(m):
    ok = ~m["collapsed"]
    d = dict(n=int(len(ok)), collapses=int((~ok).sum()))
    if ok.any():
        d.update(l2_mean=float(np.mean(m["l2"][ok])), l2_median=float(np.median(m["l2"][ok])),
                 l2_p95=float(np.percentile(m["l2"][ok], 95)),
                 over_mean=float(np.mean(m["over"][ok])),
                 over_p95=float(np.percentile(m["over"][ok], 95)),
                 over_max=float(np.max(m["over"][ok])),
                 en_mean=float(np.mean(m["en"][ok])))
    return d


# ----------------------------------------------------------------------------
# stage: verify (identities, Proposition 2, reference solution)
# ----------------------------------------------------------------------------
def stage_verify():
    res = {}
    N = 128
    k = np.arange(N // 2 + 1).astype(float)
    ik = 1j * k
    ik[-1] = 0.0
    D = lambda f: irfft(ik * rfft(f, axis=-1), n=N, axis=-1)
    rng = np.random.default_rng(1)

    # (a) Proposition 1: u^T N_w u = (3w-1)/2 * P,  P = sum u_i^2 (Du)_i,  u^T delta = -3P
    errs = []
    for _ in range(200):
        u = rng.normal(size=N)                       # fully under-resolved field
        ux = D(u)
        P = np.sum(u ** 2 * ux)
        delta = D(u * u) - 2 * u * ux
        e1 = abs(u @ delta + 3 * P)
        for w in (0.0, 1 / 3, 0.7, 1.0):
            Nw = w * u * ux + (1 - w) * 0.5 * D(u * u)
            e2 = abs(u @ Nw - (3 * w - 1) / 2 * P)
            errs.append(max(e1, e2) / (np.linalg.norm(u) ** 3))
        S = (u * ux + D(u * u)) / 3
        errs.append(abs(u @ S) / np.linalg.norm(u) ** 3)
    res["identity_max_rel_error"] = float(max(errs))

    # (b) Proposition 2: delta for trigonometric polynomials of degree K
    x = 2 * np.pi * np.arange(N) / N
    rows = []
    for K in (4, 8, 16, 24, 31, 32, 40, 48, 60):
        vals = []
        for _ in range(20):
            u = sum(rng.normal() * np.sin(j * x) + rng.normal() * np.cos(j * x) for j in range(1, K + 1))
            u = u / np.abs(u).max()
            vals.append(np.abs(D(u * u) - 2 * u * D(u)).max())
        rows.append((K, float(np.max(vals))))
    res["prop2_delta_max"] = rows

    # (c) reference solution against a fine pseudo-spectral run (N = 2048, nu >= 0.02)
    nu, a, b = make_cases(5, 6)
    nu = np.full(6, 0.02)
    Nf = 2048
    u0 = u0_on_grid(a, b, Nf)
    t0 = time.time()
    r = simulate("skew", {}, nu, u0, 1.0, 2e-4)
    xf = 2 * np.pi * np.arange(Nf) / Nf
    diffs = []
    for i in range(6):
        uex = hopf_cole(a[i], b[i], nu[i], 1.0, xf)
        diffs.append(float(np.abs(r["u"][i] - uex).max()))
    res["ref_vs_fine_spectral_maxabs"] = diffs
    # (d) quadrature refinement of Hopf-Cole itself at the smallest viscosity used
    nu2, a2, b2 = make_cases(5, 4)
    nu2 = np.full(4, 1e-3)
    x128 = 2 * np.pi * np.arange(128) / 128
    dd = []
    for i in range(4):
        u1 = hopf_cole(a2[i], b2[i], nu2[i], T_FINAL, x128)
        u2 = hopf_cole(a2[i], b2[i], nu2[i], T_FINAL, x128, hfac=64, lfac=12.0)
        dd.append(float(np.abs(u1 - u2).max()))
    res["hopf_cole_refinement_maxabs"] = dd
    json.dump(res, open(os.path.join(OUT, "verify.json"), "w"), indent=1)
    print(json.dumps(res, indent=1))


# ----------------------------------------------------------------------------
# calibration and test
# ----------------------------------------------------------------------------
METHODS = ["adv", "cons", "skew", "adv_dealias", "skew_svv", "skew_pp", "ucf"]
LABEL = {"adv": "Advective", "cons": "Conservative", "skew": "Skew (no extra viscosity)",
         "adv_dealias": "Advective + 2/3 rule", "skew_svv": "Skew + SVV",
         "skew_pp": "Skew + modal-decay sensor", "ucf": "UCF (skew + DNI sensor)"}


def configs():
    g = {}
    g["ucf"] = [dict(c1=c, eta=e) for c in (0.05, 0.1, 0.2, 0.3, 0.4, 0.6, 0.8, 1.2, 2.0, 4.0, 8.0)
                for e in (0.3, 1.0, 3.0, 10.0, 30.0, 100.0, 300.0)]
    g["skew_svv"] = [dict(e0=e, m=m) for e in (0.01, 0.03, 0.1, 0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0)
                     for m in (1, 2, 4, 8, 16, 32)]
    g["skew_pp"] = [dict(c1=c, s0=s) for c in (0.05, 0.1, 0.2, 0.3, 0.4, 0.6)
                    for s in (-3.0, -2.0, -1.5, -1.0, -0.5, 0.0)]
    return g


OVERSHOOT_TOL = 0.5      # percent of max|u0|: tolerated maximum-principle violation


def load_set(seed, n):
    nu, a, b = make_cases(seed, n)
    u0 = u0_on_grid(a, b, N0)
    cache = os.path.join(OUT, f"exact_{seed}_{n}.npy")
    if os.path.exists(cache):
        uex = np.load(cache)
    else:
        uex = exact_batch(a, b, nu, T_FINAL, N0)
        np.save(cache, uex)
    return nu, a, b, u0, uex


def stage_calib():
    nu, a, b, u0, uex = load_set(2024, 60)
    out = {}
    cfg = configs()
    for meth in ("skew_svv", "skew_pp", "ucf"):
        rows = []
        for p in cfg[meth]:
            r = simulate(meth, p, nu, u0, T_FINAL, DT)
            s = summarise(metrics(r, uex))
            rows.append(dict(params=p, **s))
            print(meth, p, s.get("l2_mean"), s.get("over_mean"), s["collapses"], flush=True)
        ok = [r for r in rows if r["collapses"] == 0]
        bestA = min(ok, key=lambda r: r["l2_mean"])             # accuracy-optimal
        feas = [r for r in ok if r["over_mean"] <= OVERSHOOT_TOL]
        if feas:                                               # accuracy under the max-principle tolerance
            bestB = min(feas, key=lambda r: r["l2_mean"])
            bestB["feasible"] = True
        else:                                                  # tolerance unattainable on this grid
            bestB = min(ok, key=lambda r: r["over_mean"])
            bestB["feasible"] = False
        out[meth] = dict(grid=rows, bestA=bestA, bestB=bestB)
    for meth in ("adv", "cons", "skew", "adv_dealias"):
        r = simulate(meth, {}, nu, u0, T_FINAL, DT)
        s = dict(params={}, **summarise(metrics(r, uex)))
        out[meth] = dict(bestA=s, bestB=s)
    json.dump(out, open(os.path.join(OUT, "calibration.json"), "w"), indent=1)
    for m in METHODS:
        print(m, "A:", out[m]["bestA"]["params"], out[m]["bestA"].get("l2_mean"), out[m]["bestA"].get("over_mean"),
              "| B:", out[m]["bestB"]["params"], out[m]["bestB"].get("l2_mean"), out[m]["bestB"].get("over_mean"))


def stage_test():
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    nu, a, b, u0, uex = load_set(777, 500)
    out = {}
    store = {}
    runs = [(m, "B") for m in METHODS] + [(m, "A") for m in ("skew_svv", "skew_pp", "ucf")]
    for meth, op in runs:
        p = cal[meth]["best" + op]["params"]
        t0 = time.time()
        r = simulate(meth, p, nu, u0, T_FINAL, DT)
        wall = time.time() - t0
        m = metrics(r, uex)
        s = summarise(m)
        s["wall_s"] = wall
        s["params"] = p
        key0 = f"{meth}_{op}"
        out[key0] = s
        for key in ("l2", "en", "over"):
            store[f"{key0}_{key}"] = m[key]
        store[f"{key0}_col"] = m["collapsed"]
        store[f"{key0}_u"] = r["u"]
        print(key0, s, flush=True)
    store["nu"] = nu
    store["uex"] = uex
    store["u0"] = u0
    np.savez(os.path.join(OUT, "test_arrays.npz"), **store)
    json.dump(out, open(os.path.join(OUT, "test.json"), "w"), indent=1)


def stage_sweep():
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    nu, a, b = make_cases(777, 100)
    out = {}
    for N in (64, 128, 256, 512):
        u0 = u0_on_grid(a, b, N)
        uex = exact_batch(a, b, nu, T_FINAL, N)
        dt = 2e-3 if N <= 128 else (1e-3 if N == 256 else 5e-4)
        for meth in ("adv", "skew", "adv_dealias", "skew_svv", "skew_pp", "ucf"):
            p = cal[meth]["bestB"]["params"]
            r = simulate(meth, p, nu, u0, T_FINAL, dt)
            s = summarise(metrics(r, uex))
            out[f"{meth}_{N}"] = s
            print(N, meth, s, flush=True)
    json.dump(out, open(os.path.join(OUT, "sweep.json"), "w"), indent=1)


# ----------------------------------------------------------------------------
# stand-alone sensors (same formulas as inside simulate) and extra stages
# ----------------------------------------------------------------------------
def _ops(N):
    k = np.arange(N // 2 + 1).astype(float)
    ik = 1j * k
    ik[-1] = 0.0
    return k, ik


def sensor_dni(u, eta):
    N = u.shape[-1]
    k, ik = _ops(N)
    D = lambda f: irfft(ik * rfft(f, axis=-1), n=N, axis=-1)
    delta = D(u * u) - 2.0 * u * D(u)
    ad = np.abs(delta)
    Um = np.abs(u).max(axis=-1, keepdims=True)
    return ad / (ad.max(axis=-1, keepdims=True) + eta * Um ** 2), ad.max(axis=-1)


def sensor_pp(u, s0):
    N = u.shape[-1]
    dx = 2 * np.pi / N
    k, ik = _ops(N)
    hp = (k > N // 4).astype(float)
    sm = np.exp(-(k * 3.0 * dx) ** 2 / 2)
    v = rfft(u, axis=-1)
    Um = np.abs(u).max(axis=-1, keepdims=True)
    uhp = irfft(v * hp, n=N, axis=-1)
    Ehp = np.maximum(irfft(rfft(uhp * uhp, axis=-1) * sm, n=N, axis=-1), 0.0)
    Et = np.maximum(irfft(rfft(u * u, axis=-1) * sm, n=N, axis=-1), 0.0)
    s = np.log10(Ehp / (Et + 1e-8 * Um ** 2) + 1e-30)
    return np.where(s < s0 - 1, 0.0, np.where(s > s0 + 1, 1.0, 0.5 * (1 + np.sin(np.pi * (s - s0) / 2))))


def load_family(family, seed, n):
    nu, a, b = make_cases(seed, n, family=family)
    u0 = u0_on_grid(a, b, N0)
    cache = os.path.join(OUT, f"exact_{family}_{seed}_{n}.npy")
    if os.path.exists(cache):
        uex = np.load(cache)
    else:
        uex = exact_batch(a, b, nu, T_FINAL, N0)
        np.save(cache, uex)
    return nu, a, b, u0, uex


def stage_family():
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    out, store = {}, {}
    for fam, seed in (("flat8", 4242), ("saw12", 9001)):
        nu, a, b, u0, uex = load_family(fam, seed, 300)
        for meth in ("adv", "cons", "skew", "adv_dealias", "skew_svv", "skew_pp", "ucf"):
            p = cal[meth]["bestB"]["params"]
            r = simulate(meth, p, nu, u0, T_FINAL, DT)
            m = metrics(r, uex)
            out[f"{fam}_{meth}"] = summarise(m)
            for key in ("l2", "over"):
                store[f"{fam}_{meth}_{key}"] = m[key]
            store[f"{fam}_{meth}_col"] = m["collapsed"]
            print(fam, meth, out[f"{fam}_{meth}"], flush=True)
    np.savez(os.path.join(OUT, "family_arrays.npz"), **store)
    json.dump(out, open(os.path.join(OUT, "family.json"), "w"), indent=1)


def stage_dt():
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    nu, a, b = make_cases(777, 100)
    u0 = u0_on_grid(a, b, N0)
    uex = exact_batch(a, b, nu, T_FINAL, N0)
    out = {}
    for dt in (4e-3, 2e-3, 1e-3, 5e-4):
        for meth in ("adv", "skew", "skew_svv", "skew_pp", "ucf"):
            p = cal[meth]["bestB"]["params"]
            r = simulate(meth, p, nu, u0, T_FINAL, dt)
            out[f"{meth}_{dt:g}"] = summarise(metrics(r, uex))
            print(dt, meth, out[f"{meth}_{dt:g}"], flush=True)
    json.dump(out, open(os.path.join(OUT, "dtsens.json"), "w"), indent=1)


def stage_sensor():
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    eta = cal["ucf"]["bestB"]["params"]["eta"]
    s0 = cal["skew_pp"]["bestB"]["params"]["s0"]
    nu, a, b, u0, uex = load_set(777, 500)
    N = N0
    x = 2 * np.pi * np.arange(N) / N
    # common under-resolved state: exact solution sampled on the grid
    S1, dmax = sensor_dni(uex, eta)
    P1 = sensor_pp(uex, s0)
    grad = (np.roll(uex, -1, axis=1) - np.roll(uex, 1, axis=1))
    ish = np.argmin(grad, axis=1)
    dist = np.abs(((x[None, :] - x[ish][:, None] + np.pi) % (2 * np.pi)) - np.pi)
    win = dist < 1.0
    def stats(S):
        act = (S > 0.05).mean(axis=1)
        mass = (S * win).sum(axis=1) / np.maximum(S.sum(axis=1), 1e-300)
        return act, mass
    a1, m1 = stats(S1)
    a2, m2 = stats(P1)
    ok2 = P1.sum(axis=1) > 0
    # resolved state: first three modes of each initial condition, renormalised
    u3 = u0_on_grid(a[:, :3], b[:, :3], N)
    u3 /= np.abs(u3).max(axis=1, keepdims=True)
    S3, d3 = sensor_dni(u3, eta)
    P3 = sensor_pp(u3, s0)
    ms = lambda v: [float(np.mean(v)), float(np.std(v))]
    out = dict(window_fraction=float(win.mean()),
               dni_active=ms(a1), pp_active=ms(a2[ok2]), pp_n_nonzero=int(ok2.sum()),
               dni_mass_near=ms(m1), pp_mass_near=ms(m2[ok2]),
               resolved_dni_maxS=[float(S3.max()), float(np.median(S3.max(axis=1)))],
               resolved_dni_maxdelta=float(d3.max()),
               resolved_pp_maxramp=float(P3.max()),
               shock_dni_maxS=ms(S1.max(axis=1)), shock_maxdelta=ms(dmax))
    json.dump(out, open(os.path.join(OUT, "sensor_stats.json"), "w"), indent=1)
    print(json.dumps(out, indent=1))


# ----------------------------------------------------------------------------
# confirmatory test, per-grid recalibration, cost, saw12 diagnostic, defect table
# ----------------------------------------------------------------------------
def stage_confirm():
    """Fresh seed, parameters frozen at the values of calibration.json (never touched after this file existed)."""
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    nu, a, b, u0, uex = load_family("trig4", 31415, 500)
    out, store = {}, {}
    for meth in METHODS:
        for op in (("B",) if meth in ("adv", "cons", "skew", "adv_dealias") else ("A", "B")):
            if meth == "skew_svv" and op == "A":
                continue
            p = cal[meth]["best" + op]["params"]
            r = simulate(meth, p, nu, u0, T_FINAL, DT)
            m = metrics(r, uex)
            s = summarise(m)
            for thr in (1, 5, 10, 20):
                s[f"over_gt{thr}"] = int(np.sum(m["over"][~m["collapsed"]] > thr))
            out[f"{meth}_{op}"] = s
            for key in ("l2", "over"):
                store[f"{meth}_{op}_{key}"] = m[key]
            store[f"{meth}_{op}_col"] = m["collapsed"]
            print(meth, op, s, flush=True)
    np.savez(os.path.join(OUT, "confirm_arrays.npz"), **store)
    json.dump(out, open(os.path.join(OUT, "confirm.json"), "w"), indent=1)


def stage_recal():
    """Re-calibrate UCF and the modal-decay baseline on every grid (reduced grids, 30 cases of seed 2024),
    then test with fixed (N = 128) and with re-calibrated parameters on the first 100 test cases."""
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    nu_c, a_c, b_c = make_cases(2024, 60)
    nu_c, a_c, b_c = nu_c[:30], a_c[:30], b_c[:30]
    nu_t, a_t, b_t = make_cases(777, 100)
    cfg = dict(
        ucf=[dict(c1=c, eta=e) for c in (0.15, 0.3, 0.6, 1.2, 2.4) for e in (3.0, 10.0, 30.0)],
        skew_pp=[dict(c1=c, s0=s) for c in (0.1, 0.2, 0.4, 0.8) for s in (-3.0, -2.5, -2.0, -1.5)])
    out = {}
    for N in (64, 256, 512):
        dt = 2e-3 if N <= 128 else (1e-3 if N == 256 else 5e-4)
        u0c = u0_on_grid(a_c, b_c, N)
        uexc = exact_batch(a_c, b_c, nu_c, T_FINAL, N)
        u0t = u0_on_grid(a_t, b_t, N)
        uext = exact_batch(a_t, b_t, nu_t, T_FINAL, N)
        for meth in ("ucf", "skew_pp"):
            rows = []
            for p in cfg[meth]:
                r = simulate(meth, p, nu_c, u0c, T_FINAL, dt)
                s = summarise(metrics(r, uexc))
                rows.append(dict(params=p, **s))
            ok = [r for r in rows if r["collapses"] == 0 and r["over_mean"] <= OVERSHOOT_TOL]
            best = min(ok, key=lambda r: r["l2_mean"]) if ok else min(rows, key=lambda r: r["over_mean"])
            res = {}
            for tag, p in (("recal", best["params"]), ("fixed", cal[meth]["bestB"]["params"])):
                r = simulate(meth, p, nu_t, u0t, T_FINAL, dt)
                res[tag] = dict(params=p, **summarise(metrics(r, uext)))
            out[f"{meth}_{N}"] = dict(feasible=bool(ok), **res)
            print(N, meth, out[f"{meth}_{N}"], flush=True)
    json.dump(out, open(os.path.join(OUT, "recal.json"), "w"), indent=1)


def stage_cost():
    import platform, timeit
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    out = dict(machine=platform.processor() or platform.machine(), python=platform.python_version(),
               numpy=np.__version__, cpus=os.cpu_count())
    eta = cal["ucf"]["bestB"]["params"]["eta"]
    s0 = cal["skew_pp"]["bestB"]["params"]["s0"]
    rng = np.random.default_rng(0)
    for N in (64, 128, 256, 512):
        u = rng.normal(size=(50, N))
        t1 = min(timeit.repeat(lambda: sensor_dni(u, eta), number=50, repeat=5)) / 50
        t2 = min(timeit.repeat(lambda: sensor_pp(u, s0), number=50, repeat=5)) / 50
        nu, a, b = make_cases(5, 50)
        u0 = u0_on_grid(a, b, N)
        row = dict(sensor_dni_ms=1e3 * t1, sensor_pp_ms=1e3 * t2)
        for meth in ("skew", "skew_svv", "skew_pp", "ucf"):
            p = cal[meth]["bestB"]["params"]
            tt = min(timeit.repeat(lambda: simulate(meth, p, nu, u0, 0.2, 2e-3), number=1, repeat=5))
            row[f"run_{meth}_s"] = tt
        out[str(N)] = row
        print(N, row, flush=True)
    json.dump(out, open(os.path.join(OUT, "cost.json"), "w"), indent=1)


def stage_sawdiag():
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    nu, a, b, u0, uex = load_family("saw12", 9001, 300)
    pB = cal["ucf"]["bestB"]["params"]
    r = simulate("ucf", pB, nu, u0, T_FINAL, DT)
    m = metrics(r, uex)
    bad = np.where(m["over"] > 5)[0]
    out = dict(bad=[int(i) for i in bad], nu_bad=[float(nu[i]) for i in bad], over_bad=[float(m["over"][i]) for i in bad])
    # time at which the violation first exceeds 5%
    first = []
    for i in bad:
        tf = None
        for T in (0.05, 0.1, 0.2, 0.4, 0.8, 1.2, 1.6, 2.0):
            rr = simulate("ucf", pB, nu[i:i + 1], u0[i:i + 1], T, DT)
            if (rr["maxu"][0] - 1) * 100 > 5:
                tf = T; break
        first.append(tf)
    out["first_T_over5"] = first
    # initial defect relative to U^2
    S0, d0 = sensor_dni(u0, pB["eta"])
    rel = d0 / np.abs(u0).max(axis=1) ** 2
    good = np.setdiff1d(np.arange(300), bad)
    out["delta0_rel_bad"] = float(np.mean(rel[bad])); out["delta0_rel_good"] = float(np.mean(rel[good]))
    # does a feasible alternative of the calibration grid remove them? (diagnostic only; not a tuning on test data)
    alts = [dict(c1=1.2, eta=10.0), dict(c1=4.0, eta=30.0), dict(c1=0.8, eta=3.0), dict(c1=2.0, eta=10.0), dict(c1=0.4, eta=0.3), dict(c1=0.6, eta=1.0)]
    out["alts"] = []
    for p in alts:
        rr = simulate("ucf", p, nu, u0, T_FINAL, DT)
        mm = metrics(rr, uex)
        out["alts"].append(dict(params=p, l2=float(np.mean(mm["l2"])), over_mean=float(np.mean(mm["over"])),
                                gt1=int((mm["over"] > 1).sum()), gt5=int((mm["over"] > 5).sum()),
                                gt10=int((mm["over"] > 10).sum()), gt20=int((mm["over"] > 20).sum())))
        print(out["alts"][-1], flush=True)
    json.dump(out, open(os.path.join(OUT, "sawdiag.json"), "w"), indent=1)
    print(json.dumps(out, indent=1))


def stage_defect():
    rows = []
    rng = np.random.default_rng(11)
    for N in (64, 128, 256):
        k, ik = _ops(N)
        D = lambda f: irfft(ik * rfft(f), n=N)
        x = 2 * np.pi * np.arange(N) / N
        for K in (N // 4 - 8, N // 4 - 1, N // 4, N // 4 + 1, N // 4 + 8):
            l2, li = [], []
            for _ in range(30):
                u = sum(rng.normal() * np.sin(j * x) + rng.normal() * np.cos(j * x) for j in range(1, K + 1))
                u /= np.abs(u).max()
                dl = D(u * u) - 2 * u * D(u)
                l2.append(np.linalg.norm(dl) / np.sqrt(N)); li.append(np.abs(dl).max())
            rows.append(dict(N=N, K=K, rms_median=float(np.median(l2)), max_median=float(np.median(li)), max_max=float(np.max(li))))
            print(rows[-1], flush=True)
    json.dump(rows, open(os.path.join(OUT, "defect_table.json"), "w"), indent=1)


def stage_tail():
    """Operating point C (tail-controlled): chosen on the calibration grid only, then tested on fresh seeds
    together with the frozen operating point B.  C: minimum mean error subject to mean M <= 0.5 % and
    max M <= 1 % over the calibration cases."""
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    pts = {}
    for meth in ("ucf", "skew_pp"):
        g = [r for r in cal[meth]["grid"] if r["collapses"] == 0 and r["over_mean"] <= OVERSHOOT_TOL and r["over_max"] <= 1.0]
        pts[meth] = dict(C=min(g, key=lambda r: r["l2_mean"]), B=cal[meth]["bestB"])
    json.dump({m: dict(C=pts[m]["C"]["params"], B=pts[m]["B"]["params"]) for m in pts}, open(os.path.join(OUT, "pointC.json"), "w"), indent=1)
    out, store = {}, {}
    for fam, seed, n in (("trig4", 27182, 500), ("flat8", 14142, 300), ("saw12", 16180, 300)):
        nu, a, b, u0, uex = load_family(fam, seed, n)
        for meth, op, p in (("skew_svv", "B", cal["skew_svv"]["bestB"]["params"]),
                            ("skew_pp", "B", pts["skew_pp"]["B"]["params"]), ("skew_pp", "C", pts["skew_pp"]["C"]["params"]),
                            ("ucf", "B", pts["ucf"]["B"]["params"]), ("ucf", "C", pts["ucf"]["C"]["params"])):
            r = simulate(meth, p, nu, u0, T_FINAL, DT)
            m = metrics(r, uex)
            sm = summarise(m)
            for thr in (1, 5, 10, 20):
                sm[f"over_gt{thr}"] = int(np.sum(m["over"][~m["collapsed"]] > thr))
            out[f"{fam}_{meth}_{op}"] = dict(seed=seed, params=p, **sm)
            store[f"{fam}_{meth}_{op}_l2"] = m["l2"]; store[f"{fam}_{meth}_{op}_over"] = m["over"]
            print(fam, meth, op, sm, flush=True)
    np.savez(os.path.join(OUT, "tail_arrays.npz"), **store)
    json.dump(out, open(os.path.join(OUT, "tail.json"), "w"), indent=1)


def stage_loc():
    """Locally normalised DNI sensors (no global maximum): calibrate on seed 2024, then test on fresh seeds."""
    nu, a, b, u0, uex = load_set(2024, 60)
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    res = {}
    for meth in ("ucfL", "ucfQ"):
        rows = []
        for c1 in (0.05, 0.1, 0.2, 0.4, 0.8, 1.6, 3.2, 6.4):
            for eta in (0.001, 0.003, 0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0):
                p = dict(c1=c1, eta=eta)
                r = simulate(meth, p, nu, u0, T_FINAL, DT)
                sm = summarise(metrics(r, uex))
                rows.append(dict(params=p, **sm))
        ok = [r for r in rows if r["collapses"] == 0]
        feas = [r for r in ok if r["over_mean"] <= OVERSHOOT_TOL]
        feas1 = [r for r in feas if r["over_max"] <= 1.0]
        res[meth] = dict(grid=rows, bestA=min(ok, key=lambda r: r["l2_mean"]),
                         bestB=min(feas, key=lambda r: r["l2_mean"]) if feas else None,
                         bestC=min(feas1, key=lambda r: r["l2_mean"]) if feas1 else None)
        print(meth, "A", res[meth]["bestA"]["params"], res[meth]["bestA"]["l2_mean"], "B", res[meth]["bestB"] and (res[meth]["bestB"]["params"], res[meth]["bestB"]["l2_mean"], res[meth]["bestB"]["over_mean"]),
              "C", res[meth]["bestC"] and (res[meth]["bestC"]["params"], res[meth]["bestC"]["l2_mean"]), flush=True)
    json.dump(res, open(os.path.join(OUT, "loc_calibration.json"), "w"), indent=1)


def stage_loctest():
    lc = json.load(open(os.path.join(OUT, "loc_calibration.json")))
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    pts = [("skew_svv", "B", cal["skew_svv"]["bestB"]["params"]), ("skew_pp", "B", cal["skew_pp"]["bestB"]["params"]),
           ("ucf", "B", cal["ucf"]["bestB"]["params"])]
    for m in ("ucfL", "ucfQ"):
        for op in ("B", "C"):
            if lc[m]["best" + op]:
                pts.append((m, op, lc[m]["best" + op]["params"]))
    out, store = {}, {}
    for fam, seed, n in (("trig4", 55555, 500), ("flat8", 13579, 300), ("saw12", 24680, 300)):
        nu, a, b, u0, uex = load_family(fam, seed, n)
        for meth, op, p in pts:
            r = simulate(meth, p, nu, u0, T_FINAL, DT)
            m_ = metrics(r, uex)
            sm = summarise(m_)
            for thr in (1, 5, 10, 20):
                sm[f"over_gt{thr}"] = int(np.sum(m_["over"][~m_["collapsed"]] > thr))
            out[f"{fam}_{meth}_{op}"] = dict(seed=seed, params=p, **sm)
            store[f"{fam}_{meth}_{op}_l2"] = m_["l2"]; store[f"{fam}_{meth}_{op}_over"] = m_["over"]
            print(fam, meth, op, p, round(sm["l2_mean"], 4), round(sm["over_mean"], 3), round(sm["over_max"], 1), sm["over_gt1"], sm["over_gt5"], flush=True)
    np.savez(os.path.join(OUT, "loctest_arrays.npz"), **store)
    json.dump(out, open(os.path.join(OUT, "loctest.json"), "w"), indent=1)


def stage_locsweep():
    lc = json.load(open(os.path.join(OUT, "loc_calibration.json")))
    cal = json.load(open(os.path.join(OUT, "calibration.json")))
    nu, a, b = make_cases(31415, 100)
    out = {}
    pts = [("skew_pp", cal["skew_pp"]["bestB"]["params"]), ("ucf", cal["ucf"]["bestB"]["params"])]
    for m in ("ucfL", "ucfQ"):
        if lc[m]["bestB"]:
            pts.append((m, lc[m]["bestB"]["params"]))
    for N in (64, 128, 256, 512):
        u0 = u0_on_grid(a, b, N)
        uex = exact_batch(a, b, nu, T_FINAL, N)
        dt = 2e-3 if N <= 128 else (1e-3 if N == 256 else 5e-4)
        for meth, p in pts:
            r = simulate(meth, p, nu, u0, T_FINAL, dt)
            sm = summarise(metrics(r, uex))
            out[f"{meth}_{N}"] = sm
            print(N, meth, round(sm["l2_mean"], 4), round(sm["over_mean"], 3), flush=True)
    json.dump(out, open(os.path.join(OUT, "locsweep.json"), "w"), indent=1)


def stage_const():
    """Control without a sensor: uniform viscosity c1*h*max|u|.  Calibrate on seed 2024 (point B), test on the fresh sets."""
    nu, a, b, u0, uex = load_set(2024, 60)
    rows = []
    for c1 in (0.01, 0.02, 0.04, 0.06, 0.08, 0.1, 0.15, 0.2, 0.3, 0.4, 0.6, 0.8, 1.2):
        r = simulate("skew_const", dict(c1=c1), nu, u0, T_FINAL, DT)
        sm = summarise(metrics(r, uex)); rows.append(dict(params=dict(c1=c1), **sm))
    ok = [r for r in rows if r["collapses"] == 0]
    feas = [r for r in ok if r["over_mean"] <= OVERSHOOT_TOL]
    bestA = min(ok, key=lambda r: r["l2_mean"]); bestB = min(feas, key=lambda r: r["l2_mean"]) if feas else None
    out = dict(grid=rows, bestA=bestA, bestB=bestB)
    print("A", bestA["params"], bestA["l2_mean"], "B", bestB and (bestB["params"], bestB["l2_mean"], bestB["over_mean"]), flush=True)
    store, test = {}, {}
    pB = bestB["params"]
    for fam, seed, n in (("trig4", 55555, 500), ("flat8", 13579, 300), ("saw12", 24680, 300)):
        nu, a, b, u0, uex = load_family(fam, seed, n)
        r = simulate("skew_const", pB, nu, u0, T_FINAL, DT)
        m_ = metrics(r, uex); sm = summarise(m_)
        for thr in (1, 5, 10, 20):
            sm[f"over_gt{thr}"] = int(np.sum(m_["over"][~m_["collapsed"]] > thr))
        test[fam] = sm; store[f"{fam}_l2"] = m_["l2"]; store[f"{fam}_over"] = m_["over"]
        print(fam, sm, flush=True)
    nu, a, b = make_cases(31415, 100)
    sw = {}
    for N in (64, 128, 256, 512):
        u0 = u0_on_grid(a, b, N); uex = exact_batch(a, b, nu, T_FINAL, N)
        dt = 2e-3 if N <= 128 else (1e-3 if N == 256 else 5e-4)
        sw[str(N)] = summarise(metrics(simulate("skew_const", pB, nu, u0, T_FINAL, dt), uex)); print(N, sw[str(N)], flush=True)
    out.update(test=test, sweep=sw)
    np.savez(os.path.join(OUT, "const_arrays.npz"), **store)
    json.dump(out, open(os.path.join(OUT, "const.json"), "w"), indent=1)


if __name__ == "__main__":
    st = sys.argv[1] if len(sys.argv) > 1 else "verify"
    {"verify": stage_verify, "calib": stage_calib, "test": stage_test, "sweep": stage_sweep,
     "family": stage_family, "dt": stage_dt, "sensor": stage_sensor,
     "confirm": stage_confirm, "recal": stage_recal, "cost": stage_cost, "sawdiag": stage_sawdiag, "defect": stage_defect, "tail": stage_tail, "loc": stage_loc, "loctest": stage_loctest, "locsweep": stage_locsweep, "const": stage_const}[st]()

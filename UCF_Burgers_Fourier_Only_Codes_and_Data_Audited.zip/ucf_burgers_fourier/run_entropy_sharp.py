import json, pandas as pd
import ucf_burgers as ub
src=open('extended_benchmark.py').read(); prefix=src.split('# Use only a dedicated calibration seed')[0]
ns={'__file__':'extended_benchmark.py'}; exec(prefix,ns)
summarize=ns['summarize']
x=json.load(open('results/extended_benchmark.json'))
params={'EV_accuracy':x['selected_entropy_params_accuracy'],'EV_low_overshoot':x['selected_entropy_params_low_overshoot']}
rows=[]; summaries=[]
for seed in (8675309,424242,7777777):
 for label,p in params.items():
  st,rr=summarize('entropy_visc',p,seed,8,family='saw12',dt=ub.DT)
  st['label']=label; summaries.append(st)
  for r in rr:r['label']=label
  rows+=rr
  print(label,seed,st,flush=True)
pd.DataFrame(rows).to_csv('results/entropy_sharp_front_per_case.csv',index=False)
pd.DataFrame(summaries).to_csv('results/entropy_sharp_front_summary.csv',index=False)
# Combine with frozen non-EV methods and compute paired Wilcoxon/Holm on L2
from scipy.stats import wilcoxon
from statsmodels.stats.multitest import multipletests
base=pd.read_csv('results/sharp_front_multiseed_per_case.csv')
ev=pd.DataFrame(rows)
wide=pd.concat([base,ev],ignore_index=True).pivot_table(index=['seed','case'],columns='label',values='l2_rel')
comparisons=[]; ps=[]
for name in ['spectral_viscosity','modal_decay_sensor','uniform_viscosity_control','skew_no_av','EV_accuracy','EV_low_overshoot']:
 d=wide['UCF_DNI']-wide[name]
 res=wilcoxon(wide['UCF_DNI'],wide[name],zero_method='wilcox',alternative='two-sided',method='auto')
 comparisons.append({'contrast':f'UCF_DNI vs {name}','n':len(d),'median_delta_UCF_minus_comparator':float(d.median()),'mean_delta':float(d.mean()),'p_raw':float(res.pvalue)})
 ps.append(res.pvalue)
adj=multipletests(ps,method='holm')[1]
for a,p in zip(comparisons,adj):a['p_holm']=float(p)
json.dump({'summary':summaries,'paired_tests_vs_UCF':comparisons},open('results/entropy_sharp_front_analysis.json','w'),indent=2)
print('PAIRED',json.dumps(comparisons,indent=2))

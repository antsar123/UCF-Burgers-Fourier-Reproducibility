#!/usr/bin/env python3
"""Independent multi-seed comparison for UCF Burgers study.

Adds a residual-based entropy-viscosity comparator to the existing Fourier
collocation baselines. Calibration and test seeds are disjoint. The script
records per-case raw metrics and software/environment metadata.
"""
import os, sys, json, time, platform, hashlib, subprocess
import numpy as np
import ucf_burgers as ub

OUT=os.path.join(os.path.dirname(__file__), 'results')
os.makedirs(OUT,exist_ok=True)

# Patch the simulator with a residual-based entropy-viscosity option while
# preserving the original methods exactly. The residual is evaluated from the
# base semidiscrete viscous Burgers RHS before adding artificial viscosity.
_original_simulate=ub.simulate

def simulate(method, params, nu, u0, T, dt, rec_every=0):
    if method != 'entropy_visc':
        return _original_simulate(method,params,nu,u0,T,dt,rec_every)
    B,N=u0.shape; dx=2*np.pi/N
    k=np.arange(N//2+1,dtype=float); ik=1j*k; ik[-1]=0.0
    L=-nu[:,None]*k[None,:]**2
    def Dx(v): return np.fft.irfft(ik*v,n=N,axis=1)
    def D2(v): return np.fft.irfft(-(k**2)*v,n=N,axis=1)
    def f(v):
        u=np.fft.irfft(v,n=N,axis=1); ux=Dx(v)
        du2=Dx(np.fft.rfft(u*u,axis=1))
        nl=(u*ux+du2)/3.0
        # Base PDE tendency, excluding artificial viscosity.
        uxx=D2(v)
        ut=-nl+nu[:,None]*uxx
        eta=0.5*u*u
        qx=Dx(np.fft.rfft((u**3)/3.0,axis=1))
        etaxx=D2(np.fft.rfft(eta,axis=1))
        # Add back the exact viscous entropy-production term nu*(u_x)^2;
        # this makes the residual vanish for a resolved viscous Burgers solution.
        resid=np.abs(u*ut+qx-nu[:,None]*etaxx+nu[:,None]*ux*ux)
        denom=np.abs(eta-eta.mean(axis=1,keepdims=True))+params['eps']
        U=np.abs(u).max(axis=1,keepdims=True)
        nue=np.minimum(params['ce']*dx*dx*resid/denom,
                       params['cmax']*dx*U)
        return -np.fft.rfft(nl,axis=1)+1j*k[None,:]*np.fft.rfft(nue*ux,axis=1)
    E=np.exp(L*dt/2); E2=E*E; v=np.fft.rfft(u0,axis=1)
    nsteps=int(round(T/dt)); collapsed=np.zeros(B,dtype=bool)
    maxu=np.abs(u0).max(axis=1)
    with np.errstate(all='ignore'):
        for _ in range(nsteps):
            a=f(v); b=f(E*(v+0.5*dt*a)); c=f(E*v+0.5*dt*b); d=f(E2*v+dt*E*c)
            v=E2*v+dt/6*(E2*a+2*E*(b+c)+d)
            u=np.fft.irfft(v,n=N,axis=1); m=np.abs(u).max(axis=1)
            bad=(~np.isfinite(m))|(m>ub.COLLAPSE_LEVEL)
            if bad.any(): collapsed|=bad; v[bad]=0; m=np.where(bad,0,m)
            maxu=np.maximum(maxu,np.where(collapsed,0,m))
    u=np.fft.irfft(v,n=N,axis=1); u[collapsed]=np.nan
    return dict(u=u,collapsed=collapsed,maxu=np.where(collapsed,np.nan,maxu),hist=None)


def summarize(method,params,seed,ncase,family='trig4',dt=ub.DT):
    nu,a,b,u0,uex=ub.load_family(family,seed,ncase)
    t0=time.time(); r=simulate(method,params,nu,u0,ub.T_FINAL,dt); elapsed=time.time()-t0
    m=ub.metrics(r,uex)
    rows=[]
    for i in range(ncase):
        rows.append({'seed':seed,'family':family,'case':i,'nu':float(nu[i]),
          'l2_rel':float(m['l2'][i]) if np.isfinite(m['l2'][i]) else None,
          'energy_ratio':float(m['en'][i]) if np.isfinite(m['en'][i]) else None,
          'overshoot_pct':float(m['over'][i]) if np.isfinite(m['over'][i]) else None,
          'collapsed':bool(m['collapsed'][i])})
    ok=~m['collapsed']
    stats={'method':method,'params':params,'seed':seed,'family':family,'n':ncase,
      'collapses':int(m['collapsed'].sum()),'runtime_s':elapsed}
    if ok.any():
      for key,arr in [('l2',m['l2']),('energy_ratio',m['en']),('overshoot_pct',m['over'])]:
        stats[key+'_mean']=float(np.mean(arr[ok])); stats[key+'_median']=float(np.median(arr[ok])); stats[key+'_p95']=float(np.percentile(arr[ok],95))
    return stats,rows

# Use only a dedicated calibration seed to choose the entropy-viscosity
# coefficient. Other methods use frozen, previously calibrated settings.
cal_seed=202402; cal_n=40
cal_params=[]
for ce in (0.05,0.1,0.2,0.4,0.8):
  p={'ce':ce,'cmax':0.5,'eps':1e-10}
  s,_=summarize('entropy_visc',p,cal_seed,cal_n)
  cal_params.append(s)
  print('CAL',s,flush=True)
feasible=[x for x in cal_params if x['collapses']==0]
chosenA=min(feasible,key=lambda x:x.get('l2_mean',float('inf')))
feasB=[x for x in feasible if x.get('overshoot_pct_mean',float('inf'))<=0.5]
chosenB=min(feasB,key=lambda x:x['l2_mean']) if feasB else min(feasible,key=lambda x:x.get('overshoot_pct_mean',float('inf')))
entropy_params=chosenA['params']; entropy_params_B=chosenB['params']

cal=json.load(open(os.path.join(OUT,'calibration.json')))
methods={
 'skew_no_av':('skew',{}),
 'advective':('adv',{}),
 'dealiased_advective':('adv_dealias',{}),
 'spectral_viscosity':('skew_svv',cal['skew_svv']['bestB']['params']),
 'modal_decay_sensor':('skew_pp',cal['skew_pp']['bestB']['params']),
 'uniform_viscosity_control':('skew_const',{'c1':cal.get('const',{}).get('c1',0.1)}),
 'UCF_DNI':('ucf',cal['ucf']['bestB']['params']),
 'entropy_viscosity_accuracy':('entropy_visc',entropy_params),
 'entropy_viscosity_low_overshoot':('entropy_visc',entropy_params_B),
}
# Independent test sets: no calibration seed reused.
test_seeds=[314159,271828,161803]
all_stats=[]; all_rows=[]
for seed in test_seeds:
  for label,(meth,p) in methods.items():
    st,rows=summarize(meth,p,seed,12)
    st['label']=label; all_stats.append(st)
    for row in rows: row['label']=label
    all_rows.extend(rows)
    with open(os.path.join(OUT,'extended_benchmark_checkpoint.json'),'w') as f: json.dump({'summary':all_stats,'per_case':all_rows},f)
    print('TEST',label,seed,st,flush=True)

# Independent sharp-front generalization set (not used for calibration).
for seed in (8675309,):
  for label in ('UCF_DNI','entropy_viscosity_accuracy','entropy_viscosity_low_overshoot','spectral_viscosity','modal_decay_sensor'):
    meth,p=methods[label]; st,rows=summarize(meth,p,seed,8,family='saw12')
    st['label']=label; all_stats.append(st)
    for row in rows: row['label']=label
    all_rows.extend(rows)
    with open(os.path.join(OUT,'extended_benchmark_checkpoint.json'),'w') as f: json.dump({'summary':all_stats,'per_case':all_rows},f)
    print('SAW',label,seed,st,flush=True)

meta={'python':sys.version,'platform':platform.platform(),'numpy':np.__version__,
      'calibration_seed':cal_seed,'calibration_n':cal_n,'test_seeds':test_seeds,
      'sawtooth_seeds':[8675309],'N':ub.N0,'T':ub.T_FINAL,'dt':ub.DT,
      'note':'Entropy-viscosity residual and cap are explicitly documented in this script; calibration and test seeds are disjoint.'}
with open(os.path.join(OUT,'extended_benchmark.json'),'w') as f: json.dump({'metadata':meta,'entropy_calibration':cal_params,'selected_entropy_params_accuracy':entropy_params,'selected_entropy_params_low_overshoot':entropy_params_B,'summary':all_stats,'per_case':all_rows},f,indent=2)
import csv
with open(os.path.join(OUT,'extended_benchmark_per_case.csv'),'w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(all_rows[0])); w.writeheader(); w.writerows(all_rows)
print('DONE',meta,entropy_params,entropy_params_B)

# UCF Burgers — Experimental closure and reproducibility audit

Audit date: 2026-11-23

## Completed executable experiments

- Core mathematical verification (`verify`), calibration (`calib`), 500-case test (`test`), four-grid resolution sweep (`sweep`).
- Independent family tests (`family`), time-step sensitivity (`dt`), sensor diagnostics (`sensor`), confirmatory 500-case test (`confirm`), per-grid recalibration (`recal`), computational cost (`cost`), sawtooth-tail diagnostic (`sawdiag`), defect threshold test (`defect`), point-C tail test (`tail`), local sensor calibration/test/sweep (`loc`, `loctest`, `locsweep`), and uniform-viscosity control (`const`).
- Expanded multi-seed sharp-front benchmark, EV tests and paired Wilcoxon/Holm analysis.

## Local sensor calibration

| Sensor | A parameters | B parameters | B mean error | B mean overshoot (%) | C parameters | C max overshoot (%) |
|---|---|---|---:|---:|---|---:|
| ucfL | `{'c1': 0.4, 'eta': 1.0}` | `{'c1': 0.2, 'eta': 0.01}` | 0.07569 | 0.256 | `{'c1': 0.4, 'eta': 0.03}` | 0.338 |
| ucfQ | `{'c1': 0.2, 'eta': 0.3}` | `{'c1': 0.2, 'eta': 0.01}` | 0.07777 | 0.162 | `{'c1': 0.4, 'eta': 0.03}` | 0.466 |

## Held-out local-sensor tests (frozen parameters)

| Family | Method | n | Mean relative L2 | Mean overshoot (%) | Max overshoot (%) | Cases >5% |
|---|---|---:|---:|---:|---:|---:|
| trig4 | ucf | 500 | 0.07620 | 0.456 | 6.946 | 2 |
| trig4 | ucfL | 500 | 0.07218 | 0.163 | 3.522 | 0 |
| trig4 | ucfQ | 500 | 0.07409 | 0.115 | 3.129 | 0 |
| trig4 | skew_pp | 500 | 0.06712 | 0.252 | 1.780 | 0 |
| trig4 | skew_svv | 500 | 0.04818 | 8.680 | 21.435 | 339 |
| flat8 | ucf | 300 | 0.07423 | 0.039 | 2.178 | 0 |
| flat8 | ucfL | 300 | 0.08221 | 0.000 | 0.000 | 0 |
| flat8 | ucfQ | 300 | 0.08360 | 0.000 | 0.000 | 0 |
| flat8 | skew_pp | 300 | 0.07518 | 0.037 | 0.705 | 0 |
| flat8 | skew_svv | 300 | 0.04777 | 5.726 | 18.842 | 152 |
| saw12 | ucf | 300 | 0.08635 | 0.565 | 22.990 | 13 |
| saw12 | ucfL | 300 | 0.06086 | 0.006 | 0.880 | 0 |
| saw12 | ucfQ | 300 | 0.06237 | 0.012 | 3.023 | 0 |
| saw12 | skew_pp | 300 | 0.06339 | 0.064 | 0.619 | 0 |
| saw12 | skew_svv | 300 | 0.02764 | 9.880 | 21.632 | 209 |

Interpretation: UCF-L materially reduces the sharp-front overshoot tail relative to global UCF in the saw12 set (mean 0.006% vs 0.565%; maximum 0.88% vs 22.99% in the 300-case held-out set), while the L2 error changes from 0.0863 to 0.0609. The same ordering is not universal across all families; on flat8, UCF has lower L2 error than UCF-L. UCF-Q is an additional experimental variant, not a primary claim in the manuscript.

## Defect threshold verification

The stored identity maximum relative error is 8.869e-16. The numerical defect remains at round-off for K below N/4 and becomes non-negligible at K=N/4 for the tested even Fourier grids. Full threshold diagnostics are in `results/defect_table.json` and the original identity checks in `results/verify.json`.

## Confirmatory and robustness stages

- The independent confirmatory test (`seed=31415`, 500 cases) reproduces the manuscript-level aggregate values for SVV, modal decay and UCF (e.g. UCF mean relative L2 0.07672 and mean overshoot 0.534%).
- Per-grid recalibration at N=64, 256 and 512 is now stored in `results/recal.json`; it shows parameter dependence and does not support treating one coefficient set as optimal at every resolution.
- `results/tail.json` documents the trade-off of point C: lower tail violations at a cost in mean L2 error; UCF point C still does not eliminate all sharp-front outliers.
- The uniform-viscosity control and runtime diagnostics are in `results/const.json` and `results/cost.json`.

## Remaining reproducibility limitations

1. The manuscript/figure build pipeline is not fully automated from source; `make_figures.py` regenerates Figures 1–5, while the Word source is maintained separately.
2. A matched canonical EV implementation, Chan-type entropy-correction DG, and NOES-DG remain outside this Fourier benchmark, as qualified in the manuscript.
3. No public repository deposit or DOI has been created. A DOI should be added only after an actual public deposit.

## Main scientific conclusion

The available experiments support a carefully bounded conclusion: the discrete Leibniz defect is a mathematically interpretable indicator for under-resolution in the tested Fourier-collocation Burgers setting. UCF/UCF-L provide useful accuracy–overshoot trade-offs but do not dominate SVV or modal decay on all metrics. The paper should not claim universal superiority, positivity preservation, a maximum principle, or generalisation beyond the tested one-dimensional Burgers setting.
# Expanded UCF Burgers benchmark (reproducibility supplement)

## Scope
This supplement adds a controlled multi-seed comparison around the existing Fourier-collocation Burgers implementation. It is an experimental supplement, not a claim that UCF is universally superior.

## Methods compared
- Skew-symmetric Fourier collocation without added viscosity.
- Advective and 2/3-dealiased advective forms.
- Spectral vanishing viscosity (SVV), using the existing implementation and calibration.
- Modal-decay sensor (the existing `skew_pp` implementation).
- Uniform artificial-viscosity control.
- UCF discrete Leibniz-defect sensor (DNI).
- A residual-based entropy-viscosity-inspired Fourier comparator.

The entropy-viscosity comparator is explicitly an adapted benchmark variant, not a bitwise reproduction of Guermond–Pasquetti–Popov. At each Runge–Kutta stage it computes

`R_eta = |u*u_t + D(u^3/3) - nu*D^2(u^2/2) + nu*(D u)^2|`,

then sets

`nu_E = min(c_E*h^2*R_eta/(|eta-mean(eta)|+eps), c_max*h*||u||_inf)`

and adds the conservative flux `D(nu_E*D(u))`. The `+nu*(D u)^2` term removes the physical viscous entropy-production contribution from the residual. This comparator should be described as an entropy-residual viscosity variant, not as an exact reproduction of the original published algorithm.

## Data split and controls
- Entropy-viscosity parameter calibration: seed 202402, 40 cases, `trig4` family.
- Smooth periodic test cases: seeds 314159, 271828, and 161803; 12 cases per seed (36 total).
- Sharp-front generalization: seed 8675309; 8 `saw12` cases.
- Calibration seeds are disjoint from all test seeds.
- All methods use the same spatial grid (`N=128`), final time (`T=2`), and nominal step (`dt=0.002`) in the comparison.
- Exact reference values are computed with the existing Hopf–Cole implementation.

## Reproduction
Run from this directory (the original `ucf_burgers.py` must be beside the benchmark script):

```bash
python -m pip install -r requirements-expanded.txt
python extended_benchmark.py
python analyze_extended.py
```

The benchmark writes `results/extended_benchmark.json` and `results/extended_benchmark_per_case.csv`. The analysis writes `results/extended_benchmark_analysis.json` and `results/extended_benchmark_aggregate.csv`.

## Important interpretation
The current test results do not support a blanket accuracy-superiority claim for UCF. On the 36 smooth test cases UCF has lower overshoot than SVV but a larger mean relative L2 error. The modal-decay and entropy-residual comparators also provide different accuracy/overshoot trade-offs. In the 8 sharp-front cases, SVV has the lowest L2 error in this run, while modal decay has the smallest overshoot. Report the trade-off, not a universal ranking.

The sample sizes are useful for an expanded pilot comparison but are not yet sufficient for a high-confidence general claim. In particular, the sharp-front set has only eight cases and one independent seed. Before submission, expand it to at least three independent seeds and increase cases per seed; also verify temporal-step convergence and run the entropy-viscosity benchmark against a carefully matched implementation of the published algorithm.

## References for comparator context
1. Guermond, J.-L., Pasquetti, R., & Popov, B. (2011). Entropy viscosity method for nonlinear conservation laws. *Journal of Computational Physics*, 230(11), 4248–4267. https://doi.org/10.1016/j.jcp.2010.11.043
2. Guermond, J.-L., & Pasquetti, R. (2008). Entropy-based nonlinear viscosity for Fourier approximations of conservation laws. *Comptes Rendus Mathématique*, 346(13–14), 801–806. https://doi.org/10.1016/j.crma.2008.05.013
3. Tadmor, E. (1989). Convergence of spectral methods for nonlinear conservation laws. *SIAM Journal on Numerical Analysis*. https://doi.org/10.1137/0726003

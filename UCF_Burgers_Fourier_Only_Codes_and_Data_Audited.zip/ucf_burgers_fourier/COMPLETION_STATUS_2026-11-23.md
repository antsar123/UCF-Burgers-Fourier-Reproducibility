# حالة إغلاق التجارب — 2026-11-23

## مراحل أُعيد تشغيلها بنجاح
- verify, calib, test (500 cases), sweep (100 cases لكل N=64,128,256,512).
- family, dt, sensor, confirm (500 cases), recal (N=64,256,512), cost, sawdiag, defect, tail, loc, loctest, locsweep, const.
- extended_benchmark, run_entropy_sharp, analyze_extended.
- فحوصات Python syntax وZIP integrity.

## نتائج إضافية جديدة في هذه النسخة
- معايرة UCF-L/UCF-Q من 60 حالة seed=2024.
- اختبار local sensors: trig4 500 حالة، flat8 300، saw12 300؛ لا انهيارات في الطرق المختبرة.
- مسح UCF-L/UCF-Q عند N=64,128,256,512.
- confirmatory test seed=31415/500، per-grid recalibration، time-step sensitivity، sensor-cost diagnostics، defect-threshold diagnostics، point-C tests، uniform viscosity.

## ما بقي غير مكتمل
- Figure/build scripts: `make_figures.py`, `analysis_extra.py`, `build_paper.py` غير متاحة.
- EV comparator هو adaptation موثق وليس إعادة تنفيذ حرفية كاملة. لا توجد مقارنة مباشرة matched مع Chan-type entropy-correction DG أو NOES-DG.
- لا يوجد DOI أو repository deposit.

## الإجراء المطلوب

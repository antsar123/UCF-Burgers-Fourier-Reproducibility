#!/usr/bin/env python3
"""Run the complete available Fourier/Burgers experimental workflow.

Usage: python run_full_reproducibility.py
WARNING: this workflow is computationally intensive and overwrites result files.
"""
import subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
STAGES=[
 ("ucf_burgers.py","verify"),("ucf_burgers.py","calib"),
 ("ucf_burgers.py","test"),("ucf_burgers.py","sweep"),
 ("ucf_burgers.py","family"),("ucf_burgers.py","dt"),
 ("ucf_burgers.py","sensor"),("ucf_burgers.py","confirm"),
 ("ucf_burgers.py","recal"),("ucf_burgers.py","cost"),
 ("ucf_burgers.py","sawdiag"),("ucf_burgers.py","defect"),
 ("ucf_burgers.py","tail"),("ucf_burgers.py","loc"),
 ("ucf_burgers.py","loctest"),("ucf_burgers.py","locsweep"),
 ("ucf_burgers.py","const"),("extended_benchmark.py",),
 ("run_entropy_sharp.py",),("analyze_extended.py",),("make_figures.py",)
]
for cmd in STAGES:
 print("\n>>> "+" ".join(cmd), flush=True)
 subprocess.run([sys.executable,*cmd],cwd=ROOT,check=True)
